<!-- Note: This document is written in "markdown".  Please respect the [markdown conventions] (http://daringfireball.net/projects/markdown/) when editig. -->


###How to Run Unit Tests with Grunt###

Grunt tasks are provided to run unit tests either individuallly or in batch.

Run the single unit test `testBED`

`% grunt unittest:testBED`

Run all unit tests

`% grunt unittest`

