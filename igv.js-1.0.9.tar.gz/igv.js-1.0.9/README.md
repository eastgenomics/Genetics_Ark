igv.js
=======

Lightweight HTML-5 version of the Integrative Genomics Viewer (http://www.broadinstitute.org/igv).


igv.js is an embeddable interactive genome visualization component written in JavaScript and CSS.
It is based on the desktop [Integrative Genomics Viewer (IGV)](www.broadinstitute.org/igv), and developed by the same team.

See the [Wiki](https://github.com/igvteam/igv.js/wiki) for more information.
